import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { ArrowUpRight, Camera, Mail } from "lucide-react";
import { AppShell } from "@/components/app-shell";
import { ComplianceRing } from "@/components/compliance-ring";
import { RiskBadge } from "@/components/risk-badge";
import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";
import { CAMERAS } from "@/lib/ppe/demo";
import { applyChecks } from "@/lib/ppe/checks";
import {
  formatRelative,
  industryLabel,
  ppeLabel,
  t,
} from "@/lib/ppe/i18n";
import { cameraRuleOf, usePpeStore } from "@/lib/ppe/store";
import { useNow } from "@/lib/ppe/use-now";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({ component: Home });

function Home() {
  const locale = usePpeStore((s) => s.locale);
  const role = usePpeStore((s) => s.role);
  const sites = usePpeStore((s) => s.sites);
  const incidents = usePpeStore((s) => s.incidents);
  const scans = usePpeStore((s) => s.scans);
  const cameraRules = usePpeStore((s) => s.cameraRules);
  const settings = usePpeStore((s) => s.settings);
  const briefs = usePpeStore((s) => s.briefs);
  const clock = useNow();
  if (role === "platform") return <Navigate to="/platform" />;

  const startOfDay = new Date();
  startOfDay.setHours(0, 0, 0, 0);
  const todayScans = scans.filter((s) => s.at >= startOfDay.getTime());
  const open = incidents.filter((i) => i.status === "open");
  const recent = [...incidents].sort((a, b) => b.at - a.at).slice(0, 5);
  const latestBrief = briefs[0];

  const persons =
    todayScans.reduce((n, s) => n + s.persons, 0) ||
    scans.slice(0, 8).reduce((n, s) => n + s.persons, 0);
  const viol =
    todayScans.reduce((n, s) => n + s.violations, 0) ||
    scans.slice(0, 8).reduce((n, s) => n + s.violations, 0);
  const compliance = persons ? (persons - viol) / persons : 0.82;

  const nextIn = clock ? Math.max(0, settings.lastBriefAt + 3600_000 - clock) : 0;
  const nextMin = Math.ceil(nextIn / 60000);

  return (
    <AppShell>
      <div className="mx-auto max-w-6xl space-y-6">
        <header className="enter-up flex flex-wrap items-end justify-between gap-3">
          <div>
            <p className="text-2xs uppercase tracking-widest text-subtle">
              {t(locale, "appName")}
            </p>
            <h1 className="mt-2 text-3xl font-medium tracking-tight">
              {t(locale, "nav.dashboard")}
            </h1>
          </div>
          <Badge tone="live" className="h-8 gap-2 px-3">
            <span className="live-dot size-1.5 rounded-full bg-danger" />
            LIVE
          </Badge>
        </header>

        <section className="grid gap-4 lg:grid-cols-[minmax(0,1.1fr)_minmax(0,1.9fr)]">
          <Card className="flex flex-col items-center justify-center gap-4 py-6">
            <ComplianceRing value={compliance} label={t(locale, "kpi.compliance")} />
            <p className="text-center text-sm text-muted">
              {locale === "ar" ? "حسب فحوصات الكاميرات المفعّلة" : "Against enabled camera checks"}
            </p>
          </Card>
          <div className="grid gap-4 sm:grid-cols-3">
            <Kpi
              label={t(locale, "kpi.open")}
              value={open.length}
              hint={locale === "ar" ? "تحتاج إجراء" : "Need action"}
              danger={open.length > 0}
            />
            <Kpi
              label={t(locale, "kpi.scans")}
              value={todayScans.length || scans.length}
              hint={locale === "ar" ? "إطارات اليوم" : "Frames today"}
            />
            <Kpi
              label={t(locale, "kpi.cameras")}
              value={CAMERAS.filter((c) => cameraRuleOf(cameraRules, c.id).enabled).length}
              hint={locale === "ar" ? "كاميرات مفعّلة" : "Enabled cameras"}
            />
            <Card className="sm:col-span-3">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <p className="text-xs text-muted">{t(locale, "reports.hourly")}</p>
                  <p className="mt-1 text-sm">
                    {clock
                      ? locale === "ar"
                        ? `التالي خلال ${nextMin} د · ${settings.managerName}`
                        : `Next in ${nextMin}m · ${settings.managerName}`
                      : settings.managerName}
                  </p>
                  {latestBrief ? (
                    <p className="mt-1 text-xs text-subtle">
                      {latestBrief.violationCount}{" "}
                      {locale === "ar" ? "مخالفة في آخر تقرير" : "in last brief"}
                    </p>
                  ) : null}
                </div>
                <Link
                  to="/reports"
                  className="inline-flex h-11 items-center gap-2 rounded-md bg-elevated px-3 text-sm text-fg"
                >
                  <Mail className="size-4" />
                  {t(locale, "reports.send")}
                </Link>
              </div>
            </Card>
          </div>
        </section>

        <section>
          <div className="mb-4 flex items-center justify-between">
            <h2 className="text-base font-medium">
              {locale === "ar" ? "الكاميرات" : "Cameras"}
            </h2>
            <Link to="/scan" className="inline-flex items-center gap-1 text-sm text-muted hover:text-fg">
              {t(locale, "nav.scan")}
              <ArrowUpRight className="size-3.5" />
            </Link>
          </div>
          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {CAMERAS.map((cam) => {
              const site = sites.find((s) => s.id === cam.siteId);
              const rule = cameraRuleOf(cameraRules, cam.id);
              const viewed = cam.cached ? applyChecks(cam.cached, rule.checks) : null;
              const violators = viewed?.persons.filter((p) => !p.compliant).length ?? 0;
              return (
                <Link
                  key={cam.id}
                  to="/scan"
                  search={{ cam: cam.id }}
                  className="group overflow-hidden rounded-xl bg-surface p-1.5 shadow-[var(--shadow-border)] transition-shadow duration-150 hover:shadow-[var(--shadow-border-hover)]"
                >
                  <div className="relative aspect-video overflow-hidden rounded-lg">
                    <img
                      src={cam.image}
                      alt={locale === "ar" ? cam.nameAr : cam.name}
                      className="size-full object-cover outline outline-1 -outline-offset-1 outline-fg/10 transition-transform duration-300 group-hover:scale-[1.03]"
                    />
                    <div className="absolute start-2 top-2">
                      <Badge tone={rule.enabled ? "live" : "mute"} className="h-6 gap-1.5 px-2 text-2xs">
                        {rule.enabled ? (
                          <span className="live-dot size-1.5 rounded-full bg-danger" />
                        ) : null}
                        {rule.enabled ? "LIVE" : t(locale, "settings.disabled")}
                      </Badge>
                    </div>
                  </div>
                  <div className="px-2.5 py-3">
                    <div className="flex items-center justify-between gap-2">
                      <span className="truncate text-sm font-medium">
                        {locale === "ar" ? cam.nameAr : cam.name}
                      </span>
                      {rule.enabled ? (
                        <span
                          className={cn(
                            "font-mono text-xs tabular",
                            violators ? "text-danger" : "text-safe",
                          )}
                        >
                          {violators ? violators : "OK"}
                        </span>
                      ) : null}
                    </div>
                    <p className="truncate text-xs text-muted">
                      {site ? (locale === "ar" ? site.nameAr : site.name) : ""}
                    </p>
                    <div className="mt-2 flex flex-wrap gap-1">
                      {rule.checks.map((id) => (
                        <span
                          key={id}
                          className="rounded-full bg-elevated px-2 py-0.5 text-2xs text-muted"
                        >
                          {ppeLabel(locale, id)}
                        </span>
                      ))}
                    </div>
                  </div>
                </Link>
              );
            })}
          </div>
        </section>

        <section className="grid gap-4 lg:grid-cols-5">
          <Card className="lg:col-span-3">
            <h2 className="mb-4 text-base font-medium">
              {locale === "ar" ? "آخر المخالفات" : "Latest incidents"}
            </h2>
            <ul className="divide-y divide-border">
              {recent.map((inc) => {
                const site = sites.find((s) => s.id === inc.siteId);
                return (
                  <li key={inc.id} className="flex items-center gap-3 py-3">
                    <div
                      className={cn(
                        "size-2 shrink-0 rounded-full",
                        inc.status === "open" ? "bg-danger" : "bg-muted",
                      )}
                    />
                    <div className="min-w-0 flex-1">
                      <p className="truncate text-sm">
                        {inc.missing.map((m) => ppeLabel(locale, m)).join(" · ")}
                      </p>
                      <p className="truncate text-xs text-muted">
                        {site ? (locale === "ar" ? site.nameAr : site.name) : ""}
                        {" · "}
                        {clock ? formatRelative(locale, inc.at) : "—"}
                      </p>
                    </div>
                    <RiskBadge risk={inc.risk} locale={locale} />
                  </li>
                );
              })}
            </ul>
          </Card>
          <Card className="lg:col-span-2">
            <h2 className="mb-4 text-base font-medium">
              {locale === "ar" ? "المواقع" : "Sites"}
            </h2>
            <ul className="space-y-2">
              {sites.map((site) => {
                const siteInc = incidents.filter((i) => i.siteId === site.id);
                const openN = siteInc.filter((i) => i.status === "open").length;
                return (
                  <li
                    key={site.id}
                    className="flex items-center justify-between rounded-lg bg-elevated px-3 py-3"
                  >
                    <div className="min-w-0">
                      <p className="truncate text-sm">
                        {locale === "ar" ? site.nameAr : site.name}
                      </p>
                      <p className="text-xs text-muted">
                        {industryLabel(locale, site.industry)}
                      </p>
                    </div>
                    <span
                      className={cn(
                        "font-mono text-xs tabular",
                        openN ? "text-danger" : "text-safe",
                      )}
                    >
                      {openN}
                    </span>
                  </li>
                );
              })}
            </ul>
            <Link
              to="/scan"
              className="mt-5 flex h-11 items-center justify-center gap-2 rounded-md bg-primary text-sm font-medium text-primary-fg"
            >
              <Camera className="size-4" />
              {t(locale, "nav.scan")}
            </Link>
          </Card>
        </section>
      </div>
    </AppShell>
  );
}

function Kpi({
  label,
  value,
  hint,
  danger,
}: {
  label: string;
  value: number;
  hint: string;
  danger?: boolean;
}) {
  return (
    <Card>
      <p className="text-xs text-muted">{label}</p>
      <p
        className={cn(
          "mt-3 font-mono text-3xl font-medium tabular",
          danger ? "text-danger" : "text-fg",
        )}
      >
        {value}
      </p>
      <p className="mt-1 text-xs text-subtle">{hint}</p>
    </Card>
  );
}
